import{B as s,D as o}from"./props.LLceXkxO.js";const a=s,t=o;export{a as b,t as d};
