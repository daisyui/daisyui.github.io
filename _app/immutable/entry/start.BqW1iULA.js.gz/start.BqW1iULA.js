import{a as t}from"../chunks/entry.Du9Pxcbt.js";export{t as start};
