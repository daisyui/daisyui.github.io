import{a as t}from"../chunks/entry.gvp69KYG.js";export{t as start};
