import{a as t}from"../chunks/entry.BrnWktzK.js";export{t as start};
