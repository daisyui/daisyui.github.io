import{a as t}from"../chunks/entry.DnA9YeIO.js";export{t as start};
