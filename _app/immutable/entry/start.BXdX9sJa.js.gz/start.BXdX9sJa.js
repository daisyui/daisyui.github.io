import{a as t}from"../chunks/entry.XvxqI8Gl.js";export{t as start};
