import{a as t}from"../chunks/entry.DCB-vH1p.js";export{t as start};
