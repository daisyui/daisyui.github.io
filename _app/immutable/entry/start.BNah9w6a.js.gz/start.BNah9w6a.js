import{a as t}from"../chunks/entry.Cro6tvx1.js";export{t as start};
