import{s as it,N as W,A as nt,S as at,a as b,c as w,i as c,d,f,g,x as T,j as h,z as L,l as D,h as I,m as V,y as E,W as P,D as R}from"../chunks/scheduler.ad2d3249.js";import{S as rt,i as ot,b as k,d as S,m as C,a as j,t as M,e as A}from"../chunks/index.c712df22.js";import{g as dt,a as st}from"../chunks/spread.8a54911c.js";import{M as ct,p as vt,C as pt,a as H,r as q}from"../chunks/ClassTable.4b53689b.js";function mt(v){let t,o='<div class="w-24 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=f("div"),t.innerHTML=o,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-tk0hy4"&&(t.innerHTML=o),this.h()},h(){h(t,"class","avatar")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function ut(v){let t,o=`<div class="$$avatar">
  <div class="w-24 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function $t(v){let t,o='<div class="w-24 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-16 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',r,e,n='<div class="w-12 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',u,$,x='<div class="w-8 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=f("div"),t.innerHTML=o,s=b(),a=f("div"),a.innerHTML=i,r=b(),e=f("div"),e.innerHTML=n,u=b(),$=f("div"),$.innerHTML=x,this.h()},l(p){t=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-tk0hy4"&&(t.innerHTML=o),s=w(p),a=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-gp8thz"&&(a.innerHTML=i),r=w(p),e=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(e)!=="svelte-6mrmmj"&&(e.innerHTML=n),u=w(p),$=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T($)!=="svelte-1csmakc"&&($.innerHTML=x),this.h()},h(){h(t,"class","avatar"),h(a,"class","avatar"),h(e,"class","avatar"),h($,"class","avatar")},m(p,_){c(p,t,_),c(p,s,_),c(p,a,_),c(p,r,_),c(p,e,_),c(p,u,_),c(p,$,_)},p:L,d(p){p&&(d(t),d(s),d(a),d(r),d(e),d(u),d($))}}}function ft(v){let t,o=`<div class="$$avatar">
  <div class="w-32 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-20 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-16 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-8 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function gt(v){let t,o='<div class="w-24 rounded-xl bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-24 rounded-full bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=f("div"),t.innerHTML=o,s=b(),a=f("div"),a.innerHTML=i,this.h()},l(r){t=g(r,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-hz3is3"&&(t.innerHTML=o),s=w(r),a=g(r,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-101s0se"&&(a.innerHTML=i),this.h()},h(){h(t,"class","avatar"),h(a,"class","avatar")},m(r,e){c(r,t,e),c(r,s,e),c(r,a,e)},p:L,d(r){r&&(d(t),d(s),d(a))}}}function ht(v){let t,o=`<div class="$$avatar">
  <div class="w-24 rounded-xl">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function _t(v){let t,o='<div class="w-24 mask mask-squircle bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-24 mask mask-hexagon bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',r,e,n='<div class="w-24 mask mask-triangle bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=f("div"),t.innerHTML=o,s=b(),a=f("div"),a.innerHTML=i,r=b(),e=f("div"),e.innerHTML=n,this.h()},l(u){t=g(u,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-1v2uway"&&(t.innerHTML=o),s=w(u),a=g(u,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-rihgak"&&(a.innerHTML=i),r=w(u),e=g(u,"DIV",{class:!0,"data-svelte-h":!0}),T(e)!=="svelte-18wx5bc"&&(e.innerHTML=n),this.h()},h(){h(t,"class","avatar"),h(a,"class","avatar"),h(e,"class","avatar")},m(u,$){c(u,t,$),c(u,s,$),c(u,a,$),c(u,r,$),c(u,e,$)},p:L,d(u){u&&(d(t),d(s),d(a),d(r),d(e))}}}function bt(v){let t,o=`<div class="$$avatar">
  <div class="w-24 $$mask $$mask-squircle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-hexagon">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-triangle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function wt(v){let t,o='<div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div>';return{c(){t=f("div"),t.innerHTML=o,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-35bptl"&&(t.innerHTML=o),this.h()},h(){h(t,"class","avatar-group -space-x-6 rtl:space-x-reverse")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function Tt(v){let t,o=`<div class="$$avatar-group -space-x-6 rtl:space-x-reverse">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function xt(v){let t,o='<div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar placeholder"><div class="w-12 bg-neutral text-neutral-content"><span>+99</span></div></div>';return{c(){t=f("div"),t.innerHTML=o,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-1sty8th"&&(t.innerHTML=o),this.h()},h(){h(t,"class","avatar-group -space-x-6 rtl:space-x-reverse")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function kt(v){let t,o=`<div class="$$avatar-group -space-x-6 rtl:space-x-reverse">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar $$placeholder">
    <div class="w-12 bg-neutral text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function St(v){let t,o='<div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=f("div"),t.innerHTML=o,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-7k73qd"&&(t.innerHTML=o),this.h()},h(){h(t,"class","avatar")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function Ct(v){let t,o=`<div class="$$avatar">
  <div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function jt(v){let t,o='<div class="w-24 rounded-full bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-24 rounded-full bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=f("div"),t.innerHTML=o,s=b(),a=f("div"),a.innerHTML=i,this.h()},l(r){t=g(r,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-nnt771"&&(t.innerHTML=o),s=w(r),a=g(r,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-19oe97h"&&(a.innerHTML=i),this.h()},h(){h(t,"class","avatar online"),h(a,"class","avatar offline")},m(r,e){c(r,t,e),c(r,s,e),c(r,a,e)},p:L,d(r){r&&(d(t),d(s),d(a))}}}function Mt(v){let t,o=`<div class="$$avatar $$online">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar $$offline">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function At(v){let t,o='<div class="bg-neutral text-neutral-content rounded-full w-24"><span class="text-3xl">K</span></div>',s,a,i='<div class="bg-neutral text-neutral-content rounded-full w-16"><span class="text-xl">JO</span></div>',r,e,n='<div class="bg-neutral text-neutral-content rounded-full w-12"><span>MX</span></div>',u,$,x='<div class="bg-neutral text-neutral-content rounded-full w-8"><span class="text-xs">AA</span></div>';return{c(){t=f("div"),t.innerHTML=o,s=b(),a=f("div"),a.innerHTML=i,r=b(),e=f("div"),e.innerHTML=n,u=b(),$=f("div"),$.innerHTML=x,this.h()},l(p){t=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-27y6i8"&&(t.innerHTML=o),s=w(p),a=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-1xrfmd1"&&(a.innerHTML=i),r=w(p),e=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(e)!=="svelte-s3q2h3"&&(e.innerHTML=n),u=w(p),$=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T($)!=="svelte-19vky8x"&&($.innerHTML=x),this.h()},h(){h(t,"class","avatar placeholder"),h(a,"class","avatar online placeholder"),h(e,"class","avatar placeholder"),h($,"class","avatar placeholder")},m(p,_){c(p,t,_),c(p,s,_),c(p,a,_),c(p,r,_),c(p,e,_),c(p,u,_),c(p,$,_)},p:L,d(p){p&&(d(t),d(s),d(a),d(r),d(e),d(u),d($))}}}function Ht(v){let t,o=`<div class="$$avatar $$placeholder">
  <div class="bg-neutral text-neutral-content rounded-full w-24">
    <span class="text-3xl">K</span>
  </div>
</div> 
<div class="$$avatar $$online $$placeholder">
  <div class="bg-neutral text-neutral-content rounded-full w-16">
    <span class="text-xl">JO</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral text-neutral-content rounded-full w-8">
    <span class="text-xs">AA</span>
  </div>
</div>`,s,a,i,r;return{c(){t=f("pre"),s=D(o),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,o),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(r=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,r()}}}function Lt(v){let t,o,s,a,i,r,e,n,u,$,x,p,_,K,z,O,y,X,J,N;return t=new pt({props:{data:[{type:"component",class:"avatar",desc:"Container element"},{type:"component",class:"avatar-group",desc:"Container for grouping multiple avatars"},{type:"modifier",class:"online",desc:"shows a green dot as online indicator"},{type:"modifier",class:"offline",desc:"shows a gray dot as offline indicator"},{type:"modifier",class:"placeholder",desc:"to show some letters as avatar placeholder"}]}}),s=new H({props:{title:"Avatar",$$slots:{html:[ut],default:[mt]},$$scope:{ctx:v}}}),i=new H({props:{title:"Avatar in custom sizes",$$slots:{html:[ft],default:[$t]},$$scope:{ctx:v}}}),e=new H({props:{title:"Avatar rounded",$$slots:{html:[ht],default:[gt]},$$scope:{ctx:v}}}),u=new H({props:{title:"Avatar with mask",$$slots:{html:[bt],default:[_t]},$$scope:{ctx:v}}}),x=new H({props:{title:"Avatar group",$$slots:{html:[Tt],default:[wt]},$$scope:{ctx:v}}}),_=new H({props:{title:"Avatar group with counter",$$slots:{html:[kt],default:[xt]},$$scope:{ctx:v}}}),z=new H({props:{title:"Avatar with ring",$$slots:{html:[Ct],default:[St]},$$scope:{ctx:v}}}),y=new H({props:{title:"Avatar with presence indicator",$$slots:{html:[Mt],default:[jt]},$$scope:{ctx:v}}}),J=new H({props:{title:"Avatar placeholder",$$slots:{html:[Ht],default:[At]},$$scope:{ctx:v}}}),{c(){k(t.$$.fragment),o=b(),k(s.$$.fragment),a=b(),k(i.$$.fragment),r=b(),k(e.$$.fragment),n=b(),k(u.$$.fragment),$=b(),k(x.$$.fragment),p=b(),k(_.$$.fragment),K=b(),k(z.$$.fragment),O=b(),k(y.$$.fragment),X=b(),k(J.$$.fragment)},l(l){S(t.$$.fragment,l),o=w(l),S(s.$$.fragment,l),a=w(l),S(i.$$.fragment,l),r=w(l),S(e.$$.fragment,l),n=w(l),S(u.$$.fragment,l),$=w(l),S(x.$$.fragment,l),p=w(l),S(_.$$.fragment,l),K=w(l),S(z.$$.fragment,l),O=w(l),S(y.$$.fragment,l),X=w(l),S(J.$$.fragment,l)},m(l,m){C(t,l,m),c(l,o,m),C(s,l,m),c(l,a,m),C(i,l,m),c(l,r,m),C(e,l,m),c(l,n,m),C(u,l,m),c(l,$,m),C(x,l,m),c(l,p,m),C(_,l,m),c(l,K,m),C(z,l,m),c(l,O,m),C(y,l,m),c(l,X,m),C(J,l,m),N=!0},p(l,m){const B={};m&5&&(B.$$scope={dirty:m,ctx:l}),s.$set(B);const F={};m&5&&(F.$$scope={dirty:m,ctx:l}),i.$set(F);const G={};m&5&&(G.$$scope={dirty:m,ctx:l}),e.$set(G);const Q={};m&5&&(Q.$$scope={dirty:m,ctx:l}),u.$set(Q);const U={};m&5&&(U.$$scope={dirty:m,ctx:l}),x.$set(U);const Y={};m&5&&(Y.$$scope={dirty:m,ctx:l}),_.$set(Y);const Z={};m&5&&(Z.$$scope={dirty:m,ctx:l}),z.$set(Z);const tt={};m&5&&(tt.$$scope={dirty:m,ctx:l}),y.$set(tt);const et={};m&5&&(et.$$scope={dirty:m,ctx:l}),J.$set(et)},i(l){N||(j(t.$$.fragment,l),j(s.$$.fragment,l),j(i.$$.fragment,l),j(e.$$.fragment,l),j(u.$$.fragment,l),j(x.$$.fragment,l),j(_.$$.fragment,l),j(z.$$.fragment,l),j(y.$$.fragment,l),j(J.$$.fragment,l),N=!0)},o(l){M(t.$$.fragment,l),M(s.$$.fragment,l),M(i.$$.fragment,l),M(e.$$.fragment,l),M(u.$$.fragment,l),M(x.$$.fragment,l),M(_.$$.fragment,l),M(z.$$.fragment,l),M(y.$$.fragment,l),M(J.$$.fragment,l),N=!1},d(l){l&&(d(o),d(a),d(r),d(n),d($),d(p),d(K),d(O),d(X)),A(t,l),A(s,l),A(i,l),A(e,l),A(u,l),A(x,l),A(_,l),A(z,l),A(y,l),A(J,l)}}}function Dt(v){let t,o;const s=[v[1],lt];let a={$$slots:{default:[Lt]},$$scope:{ctx:v}};for(let i=0;i<s.length;i+=1)a=W(a,s[i]);return t=new ct({props:a}),{c(){k(t.$$.fragment)},l(i){S(t.$$.fragment,i)},m(i,r){C(t,i,r),o=!0},p(i,[r]){const e=r&2?dt(s,[r&2&&st(i[1]),r&0&&st(lt)]):{};r&5&&(e.$$scope={dirty:r,ctx:i}),t.$set(e)},i(i){o||(j(t.$$.fragment,i),o=!0)},o(i){M(t.$$.fragment,i),o=!1},d(i){A(t,i)}}}const lt={title:"Avatar",desc:"Avatars are used to show a thumbnail representation of an individual or business in the interface.",published:!0,layout:"components"};function It(v,t,o){let s;return nt(v,vt,a=>o(0,s=a)),v.$$set=a=>{o(1,t=W(W({},t),at(a)))},t=at(t),[s,t]}class qt extends rt{constructor(t){super(),ot(this,t,It,Dt,it,{})}}export{qt as component};
