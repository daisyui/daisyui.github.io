import{e as k,a,f as Z,i as c,t as e,b as l,c as w}from"../chunks/disclose-version.ctAPnXXB.js";import{a as v}from"../chunks/actions.D_WyPHWg.js";import{l as P,s as B}from"../chunks/props.BH0qENYe.js";import{u as S,s as F}from"../chunks/store.DhJ2LkXK.js";import{M as T}from"../chunks/mdsvex-components.CISdKOSk.js";import{C as O,a as h,r as d,p as D}from"../chunks/ClassTable.D_femxPu.js";import"../chunks/entry.DpYwZM8Q.js";var E=e('<label class="swap"><input type="checkbox"> <div class="swap-on">ON</div> <div class="swap-off">OFF</div></label>'),N=e('<pre slot="html"> </pre>'),z=e('<label class="swap"><input type="checkbox"> <svg class="swap-on fill-current" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"><path d="M14,3.23V5.29C16.89,6.15 19,8.83 19,12C19,15.17 16.89,17.84 14,18.7V20.77C18,19.86 21,16.28 21,12C21,7.72 18,4.14 14,3.23M16.5,12C16.5,10.23 15.5,8.71 14,7.97V16C15.5,15.29 16.5,13.76 16.5,12M3,9V15H7L12,20V4L7,9H3Z"></path></svg> <svg class="swap-off fill-current" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"><path d="M3,9H7L12,4V20L7,15H3V9M16.59,12L14,9.41L15.41,8L18,10.59L20.59,8L22,9.41L19.41,12L22,14.59L20.59,16L18,13.41L15.41,16L14,14.59L16.59,12Z"></path></svg></label>'),I=e('<pre slot="html"> </pre>'),J=e('<label class="swap swap-rotate"><input type="checkbox"> <svg class="swap-on fill-current w-10 h-10" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5.64,17l-.71.71a1,1,0,0,0,0,1.41,1,1,0,0,0,1.41,0l.71-.71A1,1,0,0,0,5.64,17ZM5,12a1,1,0,0,0-1-1H3a1,1,0,0,0,0,2H4A1,1,0,0,0,5,12Zm7-7a1,1,0,0,0,1-1V3a1,1,0,0,0-2,0V4A1,1,0,0,0,12,5ZM5.64,7.05a1,1,0,0,0,.7.29,1,1,0,0,0,.71-.29,1,1,0,0,0,0-1.41l-.71-.71A1,1,0,0,0,4.93,6.34Zm12,.29a1,1,0,0,0,.7-.29l.71-.71a1,1,0,1,0-1.41-1.41L17,5.64a1,1,0,0,0,0,1.41A1,1,0,0,0,17.66,7.34ZM21,11H20a1,1,0,0,0,0,2h1a1,1,0,0,0,0-2Zm-9,8a1,1,0,0,0-1,1v1a1,1,0,0,0,2,0V20A1,1,0,0,0,12,19ZM18.36,17A1,1,0,0,0,17,18.36l.71.71a1,1,0,0,0,1.41,0,1,1,0,0,0,0-1.41ZM12,6.5A5.5,5.5,0,1,0,17.5,12,5.51,5.51,0,0,0,12,6.5Zm0,9A3.5,3.5,0,1,1,15.5,12,3.5,3.5,0,0,1,12,15.5Z"></path></svg> <svg class="swap-off fill-current w-10 h-10" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21.64,13a1,1,0,0,0-1.05-.14,8.05,8.05,0,0,1-3.37.73A8.15,8.15,0,0,1,9.08,5.49a8.59,8.59,0,0,1,.25-2A1,1,0,0,0,8,2.36,10.14,10.14,0,1,0,22,14.05,1,1,0,0,0,21.64,13Zm-9.5,6.69A8.14,8.14,0,0,1,7.08,5.22v.27A10.15,10.15,0,0,0,17.22,15.63a9.79,9.79,0,0,0,2.1-.22A8.11,8.11,0,0,1,12.14,19.73Z"></path></svg></label>'),U=e('<pre slot="html"> </pre>'),X=e('<label class="btn btn-circle swap swap-rotate"><input type="checkbox"> <svg class="swap-off fill-current" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 512 512"><path d="M64,384H448V341.33H64Zm0-106.67H448V234.67H64ZM64,128v42.67H448V128Z"></path></svg> <svg class="swap-on fill-current" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 512 512"><polygon points="400 145.49 366.51 112 256 222.51 145.49 112 112 145.49 222.51 256 112 366.51 145.49 400 256 289.49 366.51 400 400 366.51 289.49 256 400 145.49"></polygon></svg></label>'),Y=e('<pre slot="html"> </pre>'),j=e('<label class="swap swap-flip text-9xl"><input type="checkbox"> <div class="swap-on">😈</div> <div class="swap-off">😇</div></label>'),q=e('<pre slot="html"> </pre>'),G=e('<div class="swap text-6xl"><div class="swap-on">🥵</div> <div class="swap-off">🥶</div></div> <div class="swap swap-active text-6xl"><div class="swap-on">🥳</div> <div class="swap-off">😭</div></div>',1),K=e('<pre slot="html"> </pre>'),Q=e("<!> <!> <!> <!> <!> <!> <!>",1);const R={title:"Swap",desc:"Swap allows you to toggle the visibility of two elements using a checkbox or a class name.",published:!0,layout:"components"};function i1(A,V){const M=P(V,["children","$$slots","$$events"]),m={};S(m);const r=()=>F(D,"$prefix",m);var $=k(),y=Z($);T(y,B(()=>M,R,{children:(C,W)=>{var f=Q(),g=Z(f);O(g,{data:[{type:"component",class:"swap",desc:"Container element"},{type:"component",class:"swap-on",desc:"The child element that should be visible when checkbox is checked or when swap is active"},{type:"component",class:"swap-off",desc:"The child element that should be visible when checkbox is not checked or when swap is not active"},{type:"component",class:"swap-indeterminate",desc:"The child element that should be visible when checkbox is indeterminate"},{type:"modifier",class:"swap-active",desc:"Activates the swap (no need for checkbox)"},{type:"modifier",class:"swap-rotate",desc:"Adds rotate effect to swap"},{type:"modifier",class:"swap-flip",desc:"Adds flip effect to swap"}]});var b=l(l(g,!0));h(b,{title:"Swap text",children:(t,o)=>{var s=E();a(t,s)},$$slots:{html:(t,o)=>{var s=N(),p=w(s);p.nodeValue=c(`<label class="$$swap">
  <input type="checkbox" />
  <div class="$$swap-on">ON</div>
  <div class="$$swap-off">OFF</div>
</label>`),v(s,(i,n)=>d(i,n),()=>({to:r()})),a(t,s)}}});var x=l(l(b,!0));h(x,{title:"Swap volume icons",children:(t,o)=>{var s=z();a(t,s)},$$slots:{html:(t,o)=>{var s=I(),p=w(s);p.nodeValue=c(`<label class="$$swap">
  
  <!-- this hidden checkbox controls the state -->
  <input type="checkbox" />
  
  <!-- volume on icon -->
  <svg class="$$swap-on fill-current" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"><path d="M14,3.23V5.29C16.89,6.15 19,8.83 19,12C19,15.17 16.89,17.84 14,18.7V20.77C18,19.86 21,16.28 21,12C21,7.72 18,4.14 14,3.23M16.5,12C16.5,10.23 15.5,8.71 14,7.97V16C15.5,15.29 16.5,13.76 16.5,12M3,9V15H7L12,20V4L7,9H3Z"/></svg>
  
  <!-- volume off icon -->
  <svg class="$$swap-off fill-current" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"><path d="M3,9H7L12,4V20L7,15H3V9M16.59,12L14,9.41L15.41,8L18,10.59L20.59,8L22,9.41L19.41,12L22,14.59L20.59,16L18,13.41L15.41,16L14,14.59L16.59,12Z"/></svg>
  
</label>`),v(s,(i,n)=>d(i,n),()=>({to:r()})),a(t,s)}}});var u=l(l(x,!0));h(u,{title:"Swap icons with rotate effect",children:(t,o)=>{var s=J();a(t,s)},$$slots:{html:(t,o)=>{var s=U(),p=w(s);p.nodeValue=c(`<label class="$$swap swap-rotate">
  
  <!-- this hidden checkbox controls the state -->
  <input type="checkbox" />
  
  <!-- sun icon -->
  <svg class="$$swap-on fill-current w-10 h-10" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5.64,17l-.71.71a1,1,0,0,0,0,1.41,1,1,0,0,0,1.41,0l.71-.71A1,1,0,0,0,5.64,17ZM5,12a1,1,0,0,0-1-1H3a1,1,0,0,0,0,2H4A1,1,0,0,0,5,12Zm7-7a1,1,0,0,0,1-1V3a1,1,0,0,0-2,0V4A1,1,0,0,0,12,5ZM5.64,7.05a1,1,0,0,0,.7.29,1,1,0,0,0,.71-.29,1,1,0,0,0,0-1.41l-.71-.71A1,1,0,0,0,4.93,6.34Zm12,.29a1,1,0,0,0,.7-.29l.71-.71a1,1,0,1,0-1.41-1.41L17,5.64a1,1,0,0,0,0,1.41A1,1,0,0,0,17.66,7.34ZM21,11H20a1,1,0,0,0,0,2h1a1,1,0,0,0,0-2Zm-9,8a1,1,0,0,0-1,1v1a1,1,0,0,0,2,0V20A1,1,0,0,0,12,19ZM18.36,17A1,1,0,0,0,17,18.36l.71.71a1,1,0,0,0,1.41,0,1,1,0,0,0,0-1.41ZM12,6.5A5.5,5.5,0,1,0,17.5,12,5.51,5.51,0,0,0,12,6.5Zm0,9A3.5,3.5,0,1,1,15.5,12,3.5,3.5,0,0,1,12,15.5Z"/></svg>
  
  <!-- moon icon -->
  <svg class="$$swap-off fill-current w-10 h-10" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21.64,13a1,1,0,0,0-1.05-.14,8.05,8.05,0,0,1-3.37.73A8.15,8.15,0,0,1,9.08,5.49a8.59,8.59,0,0,1,.25-2A1,1,0,0,0,8,2.36,10.14,10.14,0,1,0,22,14.05,1,1,0,0,0,21.64,13Zm-9.5,6.69A8.14,8.14,0,0,1,7.08,5.22v.27A10.15,10.15,0,0,0,17.22,15.63a9.79,9.79,0,0,0,2.1-.22A8.11,8.11,0,0,1,12.14,19.73Z"/></svg>
  
</label>`),v(s,(i,n)=>d(i,n),()=>({to:r()})),a(t,s)}}});var _=l(l(u,!0));h(_,{title:"Hamburger button",children:(t,o)=>{var s=X();a(t,s)},$$slots:{html:(t,o)=>{var s=Y(),p=w(s);p.nodeValue=c(`<label class="$$btn $$btn-circle $$swap $$swap-rotate">
  
  <!-- this hidden checkbox controls the state -->
  <input type="checkbox" />
  
  <!-- hamburger icon -->
  <svg class="$$swap-off fill-current" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 512 512"><path d="M64,384H448V341.33H64Zm0-106.67H448V234.67H64ZM64,128v42.67H448V128Z"/></svg>
  
  <!-- close icon -->
  <svg class="$$swap-on fill-current" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 512 512"><polygon points="400 145.49 366.51 112 256 222.51 145.49 112 112 145.49 222.51 256 112 366.51 145.49 400 256 289.49 366.51 400 400 366.51 289.49 256 400 145.49"/></svg>
  
</label>`),v(s,(i,n)=>d(i,n),()=>({to:r()})),a(t,s)}}});var L=l(l(_,!0));h(L,{title:"Swap icons with flip effect",children:(t,o)=>{var s=j();a(t,s)},$$slots:{html:(t,o)=>{var s=q(),p=w(s);p.nodeValue=c(`<label class="$$swap $$swap-flip text-9xl">
  
  <!-- this hidden checkbox controls the state -->
  <input type="checkbox" />
  
  <div class="$$swap-on">😈</div>
  <div class="$$swap-off">😇</div>
</label>`),v(s,(i,n)=>d(i,n),()=>({to:r()})),a(t,s)}}});var H=l(l(L,!0));h(H,{title:"Activate using class name instead of checkbox",desc:"Instead of working with click, it shows swap-on item if you add swap-active class name. You can add or remove swap-active class using JS",children:(t,o)=>{var s=G();a(t,s)},$$slots:{html:(t,o)=>{var s=K(),p=w(s);p.nodeValue=c(`<label class="$$swap text-6xl">
  <div class="$$swap-on">🥵</div>
  <div class="$$swap-off">🥶</div>
</label>
<label class="$$swap $$swap-active text-6xl">
  <div class="$$swap-on">🥳</div>
  <div class="$$swap-off">😭</div>
</label>`),v(s,(i,n)=>d(i,n),()=>({to:r()})),a(t,s)}}}),a(C,f)}})),a(A,$)}export{i1 as component};
