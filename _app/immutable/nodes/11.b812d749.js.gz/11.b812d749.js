import{s as it,O as B,A as nt,T as at,a as b,c as w,i as c,d,f as $,g,x as T,j as h,z as L,l as D,h as I,m as V,y as E,X as P,G as R}from"../chunks/scheduler.2199cf1f.js";import{S as ot,i as rt,b as x,d as C,m as S,a as j,t as M,e as A}from"../chunks/index.ccf04077.js";import{g as dt,a as st}from"../chunks/spread.8a54911c.js";import{M as ct,p as vt,C as pt,a as H,r as q}from"../chunks/ClassTable.122104ee.js";function ut(v){let t,r='<div class="w-24 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=$("div"),t.innerHTML=r,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-tk0hy4"&&(t.innerHTML=r),this.h()},h(){h(t,"class","avatar")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function mt(v){let t,r=`<div class="$$avatar">
  <div class="w-24 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function ft(v){let t,r='<div class="w-24 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-16 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',o,e,n='<div class="w-12 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',m,f,k='<div class="w-8 rounded bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=$("div"),t.innerHTML=r,s=b(),a=$("div"),a.innerHTML=i,o=b(),e=$("div"),e.innerHTML=n,m=b(),f=$("div"),f.innerHTML=k,this.h()},l(p){t=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-tk0hy4"&&(t.innerHTML=r),s=w(p),a=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-gp8thz"&&(a.innerHTML=i),o=w(p),e=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(e)!=="svelte-6mrmmj"&&(e.innerHTML=n),m=w(p),f=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(f)!=="svelte-1csmakc"&&(f.innerHTML=k),this.h()},h(){h(t,"class","avatar"),h(a,"class","avatar"),h(e,"class","avatar"),h(f,"class","avatar")},m(p,_){c(p,t,_),c(p,s,_),c(p,a,_),c(p,o,_),c(p,e,_),c(p,m,_),c(p,f,_)},p:L,d(p){p&&(d(t),d(s),d(a),d(o),d(e),d(m),d(f))}}}function $t(v){let t,r=`<div class="$$avatar">
  <div class="w-32 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-20 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-16 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-8 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function gt(v){let t,r='<div class="w-24 rounded-xl bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-24 rounded-full bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=$("div"),t.innerHTML=r,s=b(),a=$("div"),a.innerHTML=i,this.h()},l(o){t=g(o,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-hz3is3"&&(t.innerHTML=r),s=w(o),a=g(o,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-101s0se"&&(a.innerHTML=i),this.h()},h(){h(t,"class","avatar"),h(a,"class","avatar")},m(o,e){c(o,t,e),c(o,s,e),c(o,a,e)},p:L,d(o){o&&(d(t),d(s),d(a))}}}function ht(v){let t,r=`<div class="$$avatar">
  <div class="w-24 rounded-xl">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function _t(v){let t,r='<div class="w-24 mask mask-squircle bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-24 mask mask-hexagon bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',o,e,n='<div class="w-24 mask mask-triangle bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=$("div"),t.innerHTML=r,s=b(),a=$("div"),a.innerHTML=i,o=b(),e=$("div"),e.innerHTML=n,this.h()},l(m){t=g(m,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-1v2uway"&&(t.innerHTML=r),s=w(m),a=g(m,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-rihgak"&&(a.innerHTML=i),o=w(m),e=g(m,"DIV",{class:!0,"data-svelte-h":!0}),T(e)!=="svelte-18wx5bc"&&(e.innerHTML=n),this.h()},h(){h(t,"class","avatar"),h(a,"class","avatar"),h(e,"class","avatar")},m(m,f){c(m,t,f),c(m,s,f),c(m,a,f),c(m,o,f),c(m,e,f)},p:L,d(m){m&&(d(t),d(s),d(a),d(o),d(e))}}}function bt(v){let t,r=`<div class="$$avatar">
  <div class="w-24 $$mask $$mask-squircle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-hexagon">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-triangle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function wt(v){let t,r='<div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div>';return{c(){t=$("div"),t.innerHTML=r,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-35bptl"&&(t.innerHTML=r),this.h()},h(){h(t,"class","avatar-group -space-x-6 rtl:space-x-reverse")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function Tt(v){let t,r=`<div class="$$avatar-group -space-x-6 rtl:space-x-reverse">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function kt(v){let t,r='<div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar"><div class="w-12 bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div></div> <div class="avatar placeholder"><div class="w-12 bg-neutral-focus text-neutral-content"><span>+99</span></div></div>';return{c(){t=$("div"),t.innerHTML=r,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-1ymy4ic"&&(t.innerHTML=r),this.h()},h(){h(t,"class","avatar-group -space-x-6 rtl:space-x-reverse")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function xt(v){let t,r=`<div class="$$avatar-group -space-x-6 rtl:space-x-reverse">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar $$placeholder">
    <div class="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function Ct(v){let t,r='<div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=$("div"),t.innerHTML=r,this.h()},l(s){t=g(s,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-7k73qd"&&(t.innerHTML=r),this.h()},h(){h(t,"class","avatar")},m(s,a){c(s,t,a)},p:L,d(s){s&&d(t)}}}function St(v){let t,r=`<div class="$$avatar">
  <div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function jt(v){let t,r='<div class="w-24 rounded-full bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>',s,a,i='<div class="w-24 rounded-full bg-base-300"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component"/></div>';return{c(){t=$("div"),t.innerHTML=r,s=b(),a=$("div"),a.innerHTML=i,this.h()},l(o){t=g(o,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-nnt771"&&(t.innerHTML=r),s=w(o),a=g(o,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-19oe97h"&&(a.innerHTML=i),this.h()},h(){h(t,"class","avatar online"),h(a,"class","avatar offline")},m(o,e){c(o,t,e),c(o,s,e),c(o,a,e)},p:L,d(o){o&&(d(t),d(s),d(a))}}}function Mt(v){let t,r=`<div class="$$avatar $$online">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar $$offline">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function At(v){let t,r='<div class="bg-neutral-focus text-neutral-content rounded-full w-24"><span class="text-3xl">K</span></div>',s,a,i='<div class="bg-neutral-focus text-neutral-content rounded-full w-16"><span class="text-xl">JO</span></div>',o,e,n='<div class="bg-neutral-focus text-neutral-content rounded-full w-12"><span>MX</span></div>',m,f,k='<div class="bg-neutral-focus text-neutral-content rounded-full w-8"><span class="text-xs">AA</span></div>';return{c(){t=$("div"),t.innerHTML=r,s=b(),a=$("div"),a.innerHTML=i,o=b(),e=$("div"),e.innerHTML=n,m=b(),f=$("div"),f.innerHTML=k,this.h()},l(p){t=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-ij46vj"&&(t.innerHTML=r),s=w(p),a=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(a)!=="svelte-t13aw"&&(a.innerHTML=i),o=w(p),e=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(e)!=="svelte-1in1h64"&&(e.innerHTML=n),m=w(p),f=g(p,"DIV",{class:!0,"data-svelte-h":!0}),T(f)!=="svelte-13aj3a6"&&(f.innerHTML=k),this.h()},h(){h(t,"class","avatar placeholder"),h(a,"class","avatar online placeholder"),h(e,"class","avatar placeholder"),h(f,"class","avatar placeholder")},m(p,_){c(p,t,_),c(p,s,_),c(p,a,_),c(p,o,_),c(p,e,_),c(p,m,_),c(p,f,_)},p:L,d(p){p&&(d(t),d(s),d(a),d(o),d(e),d(m),d(f))}}}function Ht(v){let t,r=`<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span class="text-3xl">K</span>
  </div>
</div> 
<div class="$$avatar $$online $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span class="text-xl">JO</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span class="text-xs">AA</span>
  </div>
</div>`,s,a,i,o;return{c(){t=$("pre"),s=D(r),this.h()},l(e){t=g(e,"PRE",{slot:!0});var n=I(t);s=V(n,r),n.forEach(d),this.h()},h(){h(t,"slot","html")},m(e,n){c(e,t,n),E(t,s),i||(o=P(a=q.call(null,t,{to:v[0]})),i=!0)},p(e,n){a&&R(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&d(t),i=!1,o()}}}function Lt(v){let t,r,s,a,i,o,e,n,m,f,k,p,_,y,z,J,O,K,X,G;return t=new pt({props:{data:[{type:"component",class:"avatar",desc:"Container element"},{type:"component",class:"avatar-group",desc:"Container for grouping multiple avatars"},{type:"modifier",class:"online",desc:"shows a green dot as online indicator"},{type:"modifier",class:"offline",desc:"shows a gray dot as offline indicator"},{type:"modifier",class:"placeholder",desc:"to show some letters as avatar placeholder"}]}}),s=new H({props:{title:"Avatar",$$slots:{html:[mt],default:[ut]},$$scope:{ctx:v}}}),i=new H({props:{title:"Avatar in custom sizes",$$slots:{html:[$t],default:[ft]},$$scope:{ctx:v}}}),e=new H({props:{title:"Avatar rounded",$$slots:{html:[ht],default:[gt]},$$scope:{ctx:v}}}),m=new H({props:{title:"Avatar with mask",$$slots:{html:[bt],default:[_t]},$$scope:{ctx:v}}}),k=new H({props:{title:"Avatar group",$$slots:{html:[Tt],default:[wt]},$$scope:{ctx:v}}}),_=new H({props:{title:"Avatar group with counter",$$slots:{html:[xt],default:[kt]},$$scope:{ctx:v}}}),z=new H({props:{title:"Avatar with ring",$$slots:{html:[St],default:[Ct]},$$scope:{ctx:v}}}),O=new H({props:{title:"Avatar with presence indicator",$$slots:{html:[Mt],default:[jt]},$$scope:{ctx:v}}}),X=new H({props:{title:"Avatar placeholder",$$slots:{html:[Ht],default:[At]},$$scope:{ctx:v}}}),{c(){x(t.$$.fragment),r=b(),x(s.$$.fragment),a=b(),x(i.$$.fragment),o=b(),x(e.$$.fragment),n=b(),x(m.$$.fragment),f=b(),x(k.$$.fragment),p=b(),x(_.$$.fragment),y=b(),x(z.$$.fragment),J=b(),x(O.$$.fragment),K=b(),x(X.$$.fragment)},l(l){C(t.$$.fragment,l),r=w(l),C(s.$$.fragment,l),a=w(l),C(i.$$.fragment,l),o=w(l),C(e.$$.fragment,l),n=w(l),C(m.$$.fragment,l),f=w(l),C(k.$$.fragment,l),p=w(l),C(_.$$.fragment,l),y=w(l),C(z.$$.fragment,l),J=w(l),C(O.$$.fragment,l),K=w(l),C(X.$$.fragment,l)},m(l,u){S(t,l,u),c(l,r,u),S(s,l,u),c(l,a,u),S(i,l,u),c(l,o,u),S(e,l,u),c(l,n,u),S(m,l,u),c(l,f,u),S(k,l,u),c(l,p,u),S(_,l,u),c(l,y,u),S(z,l,u),c(l,J,u),S(O,l,u),c(l,K,u),S(X,l,u),G=!0},p(l,u){const F={};u&5&&(F.$$scope={dirty:u,ctx:l}),s.$set(F);const N={};u&5&&(N.$$scope={dirty:u,ctx:l}),i.$set(N);const Q={};u&5&&(Q.$$scope={dirty:u,ctx:l}),e.$set(Q);const U={};u&5&&(U.$$scope={dirty:u,ctx:l}),m.$set(U);const W={};u&5&&(W.$$scope={dirty:u,ctx:l}),k.$set(W);const Y={};u&5&&(Y.$$scope={dirty:u,ctx:l}),_.$set(Y);const Z={};u&5&&(Z.$$scope={dirty:u,ctx:l}),z.$set(Z);const tt={};u&5&&(tt.$$scope={dirty:u,ctx:l}),O.$set(tt);const et={};u&5&&(et.$$scope={dirty:u,ctx:l}),X.$set(et)},i(l){G||(j(t.$$.fragment,l),j(s.$$.fragment,l),j(i.$$.fragment,l),j(e.$$.fragment,l),j(m.$$.fragment,l),j(k.$$.fragment,l),j(_.$$.fragment,l),j(z.$$.fragment,l),j(O.$$.fragment,l),j(X.$$.fragment,l),G=!0)},o(l){M(t.$$.fragment,l),M(s.$$.fragment,l),M(i.$$.fragment,l),M(e.$$.fragment,l),M(m.$$.fragment,l),M(k.$$.fragment,l),M(_.$$.fragment,l),M(z.$$.fragment,l),M(O.$$.fragment,l),M(X.$$.fragment,l),G=!1},d(l){l&&(d(r),d(a),d(o),d(n),d(f),d(p),d(y),d(J),d(K)),A(t,l),A(s,l),A(i,l),A(e,l),A(m,l),A(k,l),A(_,l),A(z,l),A(O,l),A(X,l)}}}function Dt(v){let t,r;const s=[v[1],lt];let a={$$slots:{default:[Lt]},$$scope:{ctx:v}};for(let i=0;i<s.length;i+=1)a=B(a,s[i]);return t=new ct({props:a}),{c(){x(t.$$.fragment)},l(i){C(t.$$.fragment,i)},m(i,o){S(t,i,o),r=!0},p(i,[o]){const e=o&2?dt(s,[o&2&&st(i[1]),o&0&&st(lt)]):{};o&5&&(e.$$scope={dirty:o,ctx:i}),t.$set(e)},i(i){r||(j(t.$$.fragment,i),r=!0)},o(i){M(t.$$.fragment,i),r=!1},d(i){A(t,i)}}}const lt={title:"Avatar",desc:"Avatars are used to show a thumbnail representation of an individual or business in the interface.",published:!0,layout:"components"};function It(v,t,r){let s;return nt(v,vt,a=>r(0,s=a)),v.$$set=a=>{r(1,t=B(B({},t),at(a)))},t=at(t),[s,t]}class qt extends ot{constructor(t){super(),rt(this,t,It,Dt,it,{})}}export{qt as component};
