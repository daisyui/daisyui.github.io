import{s as qe,O as fe,A as Je,T as De,a as w,c as v,i as p,d as r,f as c,g as d,x as f,j as $,z,l as L,h as I,m as j,y as S,X as T,G as V}from"../chunks/scheduler.2199cf1f.js";import{S as Fe,i as Ke,b as g,d as _,m as b,a as k,t as x,e as M}from"../chunks/index.ccf04077.js";import{g as Ne,a as We}from"../chunks/spread.8a54911c.js";import{M as Ge,p as Xe,C as Qe,a as C,r as B}from"../chunks/ClassTable.c375b28b.js";function Ye(u){let e,i="<li><a>Item 1</a></li> <li><a>Item 2</a></li> <li><a>Item 3</a></li>";return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-mqvol9"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function Ze(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function el(u){let e,i="<li><a>Item 1</a></li> <li><a>Item 2</a></li> <li><a>Item 3</a></li>";return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-g7npz"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu menu-vertical lg:menu-horizontal bg-base-200 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function ll(u){let e,i=`<ul class="$$menu $$menu-vertical lg:$$menu-horizontal bg-base-200 $$rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function tl(u){let e,i='<li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg></a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg></a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1wqqgbk"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function al(u){let e,i=`<ul class="$$menu bg-base-200 $$rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function sl(u){let e,i='<li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg></a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg></a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-5hpexe"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu menu-horizontal bg-base-200 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function nl(u){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-200 $$rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function il(u){let e,i='<li><a class="tooltip tooltip-right" data-tip="Home"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg></a></li> <li><a class="tooltip tooltip-right" data-tip="Details"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></a></li> <li><a class="tooltip tooltip-right" data-tip="Stats"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg></a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-176dr53"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function ol(u){let e,i=`<ul class="$$menu bg-base-200 $$rounded-box">
  <li>
    <a class="tooltip tooltip-right" data-tip="Home">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a class="tooltip tooltip-right" data-tip="Details">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a class="tooltip tooltip-right" data-tip="Stats">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function rl(u){let e,i='<li><a class="tooltip" data-tip="Home"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg></a></li> <li><a class="tooltip" data-tip="Details"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></a></li> <li><a class="tooltip" data-tip="Stats"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg></a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1y2vkv5"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu menu-horizontal bg-base-200 rounded-box mt-6")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function ul(u){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-200 $$rounded-box mt-6">
  <li>
    <a class="$$tooltip" data-tip="Home">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a class="$$tooltip" data-tip="Details">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a class="$$tooltip" data-tip="Stats">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function ml(u){let e,i="<li><a>xs item 1</a></li> <li><a>xs item 2</a></li>",l,s,o="<li><a>sm item 1</a></li> <li><a>sm item 2</a></li>",m,t,n="<li><a>md item 1</a></li> <li><a>md item 2</a></li>",P,A,y="<li><a>lg item 1</a></li> <li><a>lg item 2</a></li>";return{c(){e=c("ul"),e.innerHTML=i,l=w(),s=c("ul"),s.innerHTML=o,m=w(),t=c("ul"),t.innerHTML=n,P=w(),A=c("ul"),A.innerHTML=y,this.h()},l(H){e=d(H,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-n73efi"&&(e.innerHTML=i),l=v(H),s=d(H,"UL",{class:!0,"data-svelte-h":!0}),f(s)!=="svelte-1pwa9et"&&(s.innerHTML=o),m=v(H),t=d(H,"UL",{class:!0,"data-svelte-h":!0}),f(t)!=="svelte-1wlmwna"&&(t.innerHTML=n),P=v(H),A=d(H,"UL",{class:!0,"data-svelte-h":!0}),f(A)!=="svelte-uzbf4e"&&(A.innerHTML=y),this.h()},h(){$(e,"class","menu menu-xs bg-base-200 w-56 rounded-box"),$(s,"class","menu menu-sm bg-base-200 w-56 rounded-box"),$(t,"class","menu menu-md bg-base-200 w-56 rounded-box"),$(A,"class","menu menu-lg bg-base-200 w-56 rounded-box")},m(H,E){p(H,e,E),p(H,l,E),p(H,s,E),p(H,m,E),p(H,t,E),p(H,P,E),p(H,A,E)},p:z,d(H){H&&(r(e),r(l),r(s),r(m),r(t),r(P),r(A))}}}function hl(u){let e,i=`<ul class="$$menu $$menu-xs bg-base-200 w-56 $$rounded-box">
  <li><a>xs item 1</a></li>
  <li><a>xs item 2</a></li>
</ul>
<ul class="$$menu $$menu-sm bg-base-200 w-56 $$rounded-box">
  <li><a>sm item 1</a></li>
  <li><a>sm item 2</a></li>
</ul>
<ul class="$$menu $$menu-md bg-base-200 w-56 $$rounded-box">
  <li><a>md item 1</a></li>
  <li><a>md item 2</a></li>
</ul>
<ul class="$$menu $$menu-lg bg-base-200 w-56 $$rounded-box">
  <li><a>lg item 1</a></li>
  <li><a>lg item 2</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function pl(u){let e,i='<li><a>Enabled item</a></li> <li class="disabled"><a>disabled item</a></li> <li class="disabled"><a>disabled item</a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1gwwnrs"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function cl(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li><a>Enabled item</a></li>
  <li class="$$disabled"><a>disabled item</a></li>
  <li class="$$disabled"><a>disabled item</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function dl(u){let e,i=`<li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
    Item 2</a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
      Item 1</a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
      Item 3</a></li>`;return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-uiknfk"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function $l(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    Item 2
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
      Item 1
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
      Item 3
    </a>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function wl(u){let e,i=`<li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
      Inbox
      <span class="badge badge-sm">99+</span></a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
      Updates
      <span class="badge badge-sm badge-warning">NEW</span></a></li> <li><a>Stats
      <span class="badge badge-xs badge-info"></span></a></li>`;return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1g6e7em"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 lg:menu-horizontal rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function vl(u){let e,i=`<ul class="$$menu bg-base-200 lg:$$menu-horizontal $$rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
      Inbox
      <span class="$$badge $$badge-sm">99+</span>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
      Updates
      <span class="$$badge $$badge-sm $$badge-warning">NEW</span>
    </a>
  </li>
  <li>
    <a>
      Stats
      <span class="$$badge $$badge-xs $$badge-info"></span>
    </a>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function fl(u){let e,i="<li><a>Item 1</a></li> <li><a>Item 2</a></li> <li><a>Item 3</a></li>";return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1tu4a7h"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 p-0 [&_li>*]:rounded-none")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function gl(u){let e,i=`<ul class="$$menu bg-base-200 w-56 p-0 [&_li>*]:rounded-none">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function _l(u){let e,i='<li class="menu-title">Title</li> <li><a>Item 1</a></li> <li><a>Item 2</a></li> <li><a>Item 3</a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1w0boxd"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function bl(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li class="$$menu-title">Title</li>
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function kl(u){let e,i='<li><h2 class="menu-title">Title</h2> <ul><li><a>Item 1</a></li> <li><a>Item 2</a></li> <li><a>Item 3</a></li></ul></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1i8sr25"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function xl(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li>
    <h2 class="$$menu-title">Title</h2>
    <ul>
      <li><a>Item 1</a></li>
      <li><a>Item 2</a></li>
      <li><a>Item 3</a></li>
    </ul>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Ml(u){let e,i="<li><a>Item 1</a></li> <li><a>Parent</a> <ul><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li> <li><a>Parent</a> <ul><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li></ul></li></ul></li> <li><a>Item 3</a></li>";return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-17b1bna"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function Hl(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li><a>Item 1</a></li>
  <li>
    <a>Parent</a>
    <ul>
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li>
        <a>Parent</a>
        <ul>
          <li><a>Submenu 1</a></li>
          <li><a>Submenu 2</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Cl(u){let e,i='<li><a>Item 1</a></li> <li><details open=""><summary>Parent</summary> <ul><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li> <li><details open=""><summary>Parent</summary> <ul><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li></ul></details></li></ul></details></li> <li><a>Item 3</a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-pyvi5g"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function zl(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li><a>Item 1</a></li>
  <li>
    <details open>
      <summary>Parent</summary>
      <ul>
        <li><a>Submenu 1</a></li>
        <li><a>Submenu 2</a></li>
        <li>
          <details open>
            <summary>Parent</summary>
            <ul>
              <li><a>Submenu 1</a></li>
              <li><a>Submenu 2</a></li>
            </ul>
          </details>
        </li>
      </ul>
    </details>
  </li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Ll(u){let e,i='<li><a>Item 1</a></li> <li><span class="menu-dropdown-toggle">Parent</span> <ul class="menu-dropdown"><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li></ul></li>',l,s,o='<li><a>Item 1</a></li> <li><span class="menu-dropdown-toggle menu-dropdown-show">Parent</span> <ul class="menu-dropdown menu-dropdown-show"><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li></ul></li>';return{c(){e=c("ul"),e.innerHTML=i,l=w(),s=c("ul"),s.innerHTML=o,this.h()},l(m){e=d(m,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-p9a3lp"&&(e.innerHTML=i),l=v(m),s=d(m,"UL",{class:!0,"data-svelte-h":!0}),f(s)!=="svelte-1jbw4hf"&&(s.innerHTML=o),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box"),$(s,"class","menu bg-base-200 w-56 rounded-box")},m(m,t){p(m,e,t),p(m,l,t),p(m,s,t)},p:z,d(m){m&&(r(e),r(l),r(s))}}}function Il(u){let e,i=`<ul class="$$menu bg-base-200 w-56 $$rounded-box">
  <li><a>Item 1</a></li>
  <li>
    <span class="$$menu-dropdown-toggle">Parent</span>
    <ul class="$$menu-dropdown">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
    </ul>
  </li>
</ul>
<ul class="$$menu bg-base-200 w-56 rounded-box">
  <li><a>Item 1</a></li>
  <li>
    <span class="$$menu-dropdown-toggle $$menu-dropdown-show">Parent</span>
    <ul class="$$menu-dropdown $$menu-dropdown-show">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
    </ul>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function jl(u){let e,i=`<li><a><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"></path></svg>
    resume.pdf</a></li> <li><details open=""><summary><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z"></path></svg>
        My Files</summary> <ul><li><a><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"></path></svg>
          Project-final.psd</a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"></path></svg>
          Project-final-2.psd</a></li> <li><details open=""><summary><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z"></path></svg>
              Images</summary> <ul><li><a><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"></path></svg>
                Screenshot1.png</a></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"></path></svg>
                Screenshot2.png</a></li> <li><details open=""><summary><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z"></path></svg>
                    Others</summary> <ul><li><a><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"></path></svg>
                      Screenshot3.png</a></li></ul></details></li></ul></details></li></ul></details></li> <li><a><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"></path></svg>
    reports-final-2.pdf</a></li>`;return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-sst3ub"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu menu-xs bg-base-200 rounded-lg max-w-xs w-full")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function Sl(u){let e,i=`<ul class="$$menu $$menu-xs bg-base-200 $$rounded-lg max-w-xs w-full">
  <li><a>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
    resume.pdf
  </a></li>
  <li>
    <details open>
      <summary>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z" /></svg>
        My Files
      </summary>
      <ul>
        <li><a>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
          Project-final.psd
        </a></li>
        <li><a>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
          Project-final-2.psd
        </a></li>
        <li>
          <details open>
            <summary>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z" /></svg>
              Images
            </summary>
            <ul>
              <li><a>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>
                Screenshot1.png
              </a></li>
              <li><a>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>
                Screenshot2.png
              </a></li>
              <li>
                <details open>
                  <summary>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z" /></svg>
                    Others
                  </summary>
                  <ul>
                    <li><a>
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>
                      Screenshot3.png
                    </a></li>
                  </ul>
                </details>
              </li>
            </ul>
          </details>
        </li>
      </ul>
    </details>
  </li>
  <li><a>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
    reports-final-2.pdf
  </a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Tl(u){let e,i='<li><a>Item 1</a></li> <li><a class="active">Item 2</a></li> <li><a>Item 3</a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-p5aeuy"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu bg-base-200 w-56 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function Vl(u){let e,i=`<ul class="$$menu bg-base-200 w-56">
  <li><a>Item 1</a></li>
  <li><a class="$$active">Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Bl(u){let e,i="<li><a>Item 1</a></li> <li><a>Item 2</a></li> <li><a>Item 3</a></li>";return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-19u7882"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu menu-horizontal bg-base-200 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function El(u){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-200">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Pl(u){let e,i="<li><a>Item 1</a></li> <li><a>Parent</a> <ul><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li></ul></li> <li><a>Item 3</a></li>";return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-vvwwmj"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu menu-horizontal bg-base-200 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function Al(u){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-200 $$rounded-box">
  <li><a>Item 1</a></li>
  <li>
    <a>Parent</a>
    <ul>
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function yl(u){let e,i="<li><a>Solutions</a> <ul><li><a>Design</a></li> <li><a>Development</a></li> <li><a>Hosting</a></li> <li><a>Domain register</a></li></ul></li> <li><a>Enterprise</a> <ul><li><a>CRM software</a></li> <li><a>Marketing management</a></li> <li><a>Security</a></li> <li><a>Consulting</a></li></ul></li> <li><a>Products</a> <ul><li><a>UI Kit</a></li> <li><a>Wordpress themes</a></li> <li><a>Wordpress plugins</a></li> <li><a>Open source</a> <ul><li><a>Auth management system</a></li> <li><a>VScode theme</a></li> <li><a>Color picker app</a></li></ul></li></ul></li> <li><a>Company</a> <ul><li><a>About us</a></li> <li><a>Contact us</a></li> <li><a>Privacy policy</a></li> <li><a>Press kit</a></li></ul></li>";return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-xxaw1g"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu xl:menu-horizontal lg:min-w-max bg-base-200 rounded-box")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function Ul(u){let e,i=`<ul class="$$menu xl:$$menu-horizontal lg:min-w-max bg-base-200 $$rounded-box">
  <li>
    <a>Solutions</a>
    <ul>
      <li><a>Design</a></li>
      <li><a>Development</a></li>
      <li><a>Hosting</a></li>
      <li><a>Domain register</a></li>
    </ul>
  </li>
  <li>
    <a>Enterprise</a>
    <ul>
      <li><a>CRM software</a></li>
      <li><a>Marketing management</a></li>
      <li><a>Security</a></li>
      <li><a>Consulting</a></li>
    </ul>
  </li>
  <li>
    <a>Products</a>
    <ul>
      <li><a>UI Kit</a></li>
      <li><a>Wordpress themes</a></li>
      <li><a>Wordpress plugins</a></li>
      <li>
        <a>Open source</a>
        <ul>
          <li><a>Auth management system</a></li>
          <li><a>VScode theme</a></li>
          <li><a>Color picker app</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li>
    <a>Company</a>
    <ul>
      <li><a>About us</a></li>
      <li><a>Contact us</a></li>
      <li><a>Privacy policy</a></li>
      <li><a>Press kit</a></li>
    </ul>
  </li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Rl(u){let e,i='<li><a>Item 1</a></li> <li><details open=""><summary>Parent item</summary> <ul><li><a>Submenu 1</a></li> <li><a>Submenu 2</a></li> <li><details open=""><summary>Parent</summary> <ul><li><a>item 1</a></li> <li><a>item 2</a></li></ul></details></li></ul></details></li> <li><a>Item 3</a></li>';return{c(){e=c("ul"),e.innerHTML=i,this.h()},l(l){e=d(l,"UL",{class:!0,"data-svelte-h":!0}),f(e)!=="svelte-1xa6fzw"&&(e.innerHTML=i),this.h()},h(){$(e,"class","menu lg:menu-horizontal bg-base-200 rounded-box lg:mb-64")},m(l,s){p(l,e,s)},p:z,d(l){l&&r(e)}}}function Dl(u){let e,i=`<ul class="$$menu lg:$$menu-horizontal bg-base-200 $$rounded-box lg:mb-64">
  <li><a>Item 1</a></li>
  <li>
    <details open>
      <summary>Parent item</summary>
      <ul>
        <li><a>Submenu 1</a></li>
        <li><a>Submenu 2</a></li>
        <li>
          <details open>
            <summary>Parent</summary>
            <ul>
              <li><a>item 1</a></li>
              <li><a>item 2</a></li>
            </ul>
          </details>
        </li>
      </ul>
    </details>
  </li>
  <li><a>Item 3</a></li>
</ul>`,l,s,o,m;return{c(){e=c("pre"),l=L(i),this.h()},l(t){e=d(t,"PRE",{slot:!0});var n=I(e);l=j(n,i),n.forEach(r),this.h()},h(){$(e,"slot","html")},m(t,n){p(t,e,n),S(e,l),o||(m=T(s=B.call(null,e,{to:u[0]})),o=!0)},p(t,n){s&&V(s.update)&&n&1&&s.update.call(null,{to:t[0]})},d(t){t&&r(e),o=!1,m()}}}function Wl(u){let e,i,l,s,o,m,t,n,P,A,y,H,E,le,U,te,R,ae,D,se,W,ne,O,ie,q,oe,J,re,F,ue,K,me,N,he,G,pe,X,ce,Q,de,Y,$e,Z,we,ee,ve;return e=new Qe({props:{data:[{type:"component",class:"menu",desc:"Container <ul> element"},{type:"component",class:"menu-title",desc:"Specifies the title of menu"},{type:"modifier",class:"disabled",desc:"Sets <li> as disabled"},{type:"modifier",class:"active",desc:"Applies actives style to the element inside <li>"},{type:"modifier",class:"focus",desc:"Applies focus style to the element inside <li>"},{type:"component",class:"menu-dropdown-toggle",desc:"Class name for the toggle to show/hide the `menu-dropdown` using JS"},{type:"component",class:"menu-dropdown",desc:"Class name for the collapsible <ul> if you want to show it using JS"},{type:"modifier",class:"menu-dropdown-show",desc:"Shows the `menu-dropdown-toggle` and `menu-dropdown` collapsible submenu using JS"},{type:"responsive",class:"menu-xs",desc:"Extra small size"},{type:"responsive",class:"menu-sm",desc:"Small size"},{type:"responsive",class:"menu-md",desc:"Medium size (default)"},{type:"responsive",class:"menu-lg",desc:"Large size"},{type:"responsive",class:"menu-vertical",desc:"Vertical menu (default)"},{type:"responsive",class:"menu-horizontal",desc:"Horizontal menu"}]}}),l=new C({props:{title:"Menu",$$slots:{html:[Ze],default:[Ye]},$$scope:{ctx:u}}}),o=new C({props:{title:"Responsive: vertical on small screen, horizontal on large screen",$$slots:{html:[ll],default:[el]},$$scope:{ctx:u}}}),t=new C({props:{title:"Menu with icon only",$$slots:{html:[al],default:[tl]},$$scope:{ctx:u}}}),P=new C({props:{title:"Menu with icon only (horizontal)",$$slots:{html:[nl],default:[sl]},$$scope:{ctx:u}}}),y=new C({props:{title:"Menu with icon only with tooltip",$$slots:{html:[ol],default:[il]},$$scope:{ctx:u}}}),E=new C({props:{title:"Menu with icon only (horizontal) with tooltip",$$slots:{html:[ul],default:[rl]},$$scope:{ctx:u}}}),U=new C({props:{title:"Menu sizes",classes:"flex flex-col gap-4",$$slots:{html:[hl],default:[ml]},$$scope:{ctx:u}}}),R=new C({props:{title:"Menu with disabled items",$$slots:{html:[cl],default:[pl]},$$scope:{ctx:u}}}),D=new C({props:{title:"Menu with icons",$$slots:{html:[$l],default:[dl]},$$scope:{ctx:u}}}),W=new C({props:{title:"Menu with icons and badge (responsive)",$$slots:{html:[vl],default:[wl]},$$scope:{ctx:u}}}),O=new C({props:{title:"Menu without padding and border radius",$$slots:{html:[gl],default:[fl]},$$scope:{ctx:u}}}),q=new C({props:{title:"Menu with title",$$slots:{html:[bl],default:[_l]},$$scope:{ctx:u}}}),J=new C({props:{title:"Menu with title as a parent",$$slots:{html:[xl],default:[kl]},$$scope:{ctx:u}}}),F=new C({props:{title:"Submenu",$$slots:{html:[Hl],default:[Ml]},$$scope:{ctx:u}}}),K=new C({props:{title:"Collapsible submenu",$$slots:{html:[zl],default:[Cl]},$$scope:{ctx:u}}}),N=new C({props:{title:"Collapsible submenu that works with class names",desc:"you can open/close the submenu by adding/removing `menu-dropdown-show` class using JS",$$slots:{html:[Il],default:[Ll]},$$scope:{ctx:u}}}),G=new C({props:{title:"File tree",$$slots:{html:[Sl],default:[jl]},$$scope:{ctx:u}}}),X=new C({props:{title:"Menu with active item",$$slots:{html:[Vl],default:[Tl]},$$scope:{ctx:u}}}),Q=new C({props:{title:"Horizontal menu",$$slots:{html:[El],default:[Bl]},$$scope:{ctx:u}}}),Y=new C({props:{title:"Horizontal submenu",$$slots:{html:[Al],default:[Pl]},$$scope:{ctx:u}}}),Z=new C({props:{title:"Mega menu with submenu (responsive)",$$slots:{html:[Ul],default:[yl]},$$scope:{ctx:u}}}),ee=new C({props:{title:"Collapsible with submenu (responsive)",$$slots:{html:[Dl],default:[Rl]},$$scope:{ctx:u}}}),{c(){g(e.$$.fragment),i=w(),g(l.$$.fragment),s=w(),g(o.$$.fragment),m=w(),g(t.$$.fragment),n=w(),g(P.$$.fragment),A=w(),g(y.$$.fragment),H=w(),g(E.$$.fragment),le=w(),g(U.$$.fragment),te=w(),g(R.$$.fragment),ae=w(),g(D.$$.fragment),se=w(),g(W.$$.fragment),ne=w(),g(O.$$.fragment),ie=w(),g(q.$$.fragment),oe=w(),g(J.$$.fragment),re=w(),g(F.$$.fragment),ue=w(),g(K.$$.fragment),me=w(),g(N.$$.fragment),he=w(),g(G.$$.fragment),pe=w(),g(X.$$.fragment),ce=w(),g(Q.$$.fragment),de=w(),g(Y.$$.fragment),$e=w(),g(Z.$$.fragment),we=w(),g(ee.$$.fragment)},l(a){_(e.$$.fragment,a),i=v(a),_(l.$$.fragment,a),s=v(a),_(o.$$.fragment,a),m=v(a),_(t.$$.fragment,a),n=v(a),_(P.$$.fragment,a),A=v(a),_(y.$$.fragment,a),H=v(a),_(E.$$.fragment,a),le=v(a),_(U.$$.fragment,a),te=v(a),_(R.$$.fragment,a),ae=v(a),_(D.$$.fragment,a),se=v(a),_(W.$$.fragment,a),ne=v(a),_(O.$$.fragment,a),ie=v(a),_(q.$$.fragment,a),oe=v(a),_(J.$$.fragment,a),re=v(a),_(F.$$.fragment,a),ue=v(a),_(K.$$.fragment,a),me=v(a),_(N.$$.fragment,a),he=v(a),_(G.$$.fragment,a),pe=v(a),_(X.$$.fragment,a),ce=v(a),_(Q.$$.fragment,a),de=v(a),_(Y.$$.fragment,a),$e=v(a),_(Z.$$.fragment,a),we=v(a),_(ee.$$.fragment,a)},m(a,h){b(e,a,h),p(a,i,h),b(l,a,h),p(a,s,h),b(o,a,h),p(a,m,h),b(t,a,h),p(a,n,h),b(P,a,h),p(a,A,h),b(y,a,h),p(a,H,h),b(E,a,h),p(a,le,h),b(U,a,h),p(a,te,h),b(R,a,h),p(a,ae,h),b(D,a,h),p(a,se,h),b(W,a,h),p(a,ne,h),b(O,a,h),p(a,ie,h),b(q,a,h),p(a,oe,h),b(J,a,h),p(a,re,h),b(F,a,h),p(a,ue,h),b(K,a,h),p(a,me,h),b(N,a,h),p(a,he,h),b(G,a,h),p(a,pe,h),b(X,a,h),p(a,ce,h),b(Q,a,h),p(a,de,h),b(Y,a,h),p(a,$e,h),b(Z,a,h),p(a,we,h),b(ee,a,h),ve=!0},p(a,h){const ge={};h&5&&(ge.$$scope={dirty:h,ctx:a}),l.$set(ge);const _e={};h&5&&(_e.$$scope={dirty:h,ctx:a}),o.$set(_e);const be={};h&5&&(be.$$scope={dirty:h,ctx:a}),t.$set(be);const ke={};h&5&&(ke.$$scope={dirty:h,ctx:a}),P.$set(ke);const xe={};h&5&&(xe.$$scope={dirty:h,ctx:a}),y.$set(xe);const Me={};h&5&&(Me.$$scope={dirty:h,ctx:a}),E.$set(Me);const He={};h&5&&(He.$$scope={dirty:h,ctx:a}),U.$set(He);const Ce={};h&5&&(Ce.$$scope={dirty:h,ctx:a}),R.$set(Ce);const ze={};h&5&&(ze.$$scope={dirty:h,ctx:a}),D.$set(ze);const Le={};h&5&&(Le.$$scope={dirty:h,ctx:a}),W.$set(Le);const Ie={};h&5&&(Ie.$$scope={dirty:h,ctx:a}),O.$set(Ie);const je={};h&5&&(je.$$scope={dirty:h,ctx:a}),q.$set(je);const Se={};h&5&&(Se.$$scope={dirty:h,ctx:a}),J.$set(Se);const Te={};h&5&&(Te.$$scope={dirty:h,ctx:a}),F.$set(Te);const Ve={};h&5&&(Ve.$$scope={dirty:h,ctx:a}),K.$set(Ve);const Be={};h&5&&(Be.$$scope={dirty:h,ctx:a}),N.$set(Be);const Ee={};h&5&&(Ee.$$scope={dirty:h,ctx:a}),G.$set(Ee);const Pe={};h&5&&(Pe.$$scope={dirty:h,ctx:a}),X.$set(Pe);const Ae={};h&5&&(Ae.$$scope={dirty:h,ctx:a}),Q.$set(Ae);const ye={};h&5&&(ye.$$scope={dirty:h,ctx:a}),Y.$set(ye);const Ue={};h&5&&(Ue.$$scope={dirty:h,ctx:a}),Z.$set(Ue);const Re={};h&5&&(Re.$$scope={dirty:h,ctx:a}),ee.$set(Re)},i(a){ve||(k(e.$$.fragment,a),k(l.$$.fragment,a),k(o.$$.fragment,a),k(t.$$.fragment,a),k(P.$$.fragment,a),k(y.$$.fragment,a),k(E.$$.fragment,a),k(U.$$.fragment,a),k(R.$$.fragment,a),k(D.$$.fragment,a),k(W.$$.fragment,a),k(O.$$.fragment,a),k(q.$$.fragment,a),k(J.$$.fragment,a),k(F.$$.fragment,a),k(K.$$.fragment,a),k(N.$$.fragment,a),k(G.$$.fragment,a),k(X.$$.fragment,a),k(Q.$$.fragment,a),k(Y.$$.fragment,a),k(Z.$$.fragment,a),k(ee.$$.fragment,a),ve=!0)},o(a){x(e.$$.fragment,a),x(l.$$.fragment,a),x(o.$$.fragment,a),x(t.$$.fragment,a),x(P.$$.fragment,a),x(y.$$.fragment,a),x(E.$$.fragment,a),x(U.$$.fragment,a),x(R.$$.fragment,a),x(D.$$.fragment,a),x(W.$$.fragment,a),x(O.$$.fragment,a),x(q.$$.fragment,a),x(J.$$.fragment,a),x(F.$$.fragment,a),x(K.$$.fragment,a),x(N.$$.fragment,a),x(G.$$.fragment,a),x(X.$$.fragment,a),x(Q.$$.fragment,a),x(Y.$$.fragment,a),x(Z.$$.fragment,a),x(ee.$$.fragment,a),ve=!1},d(a){a&&(r(i),r(s),r(m),r(n),r(A),r(H),r(le),r(te),r(ae),r(se),r(ne),r(ie),r(oe),r(re),r(ue),r(me),r(he),r(pe),r(ce),r(de),r($e),r(we)),M(e,a),M(l,a),M(o,a),M(t,a),M(P,a),M(y,a),M(E,a),M(U,a),M(R,a),M(D,a),M(W,a),M(O,a),M(q,a),M(J,a),M(F,a),M(K,a),M(N,a),M(G,a),M(X,a),M(Q,a),M(Y,a),M(Z,a),M(ee,a)}}}function Ol(u){let e,i;const l=[u[1],Oe];let s={$$slots:{default:[Wl]},$$scope:{ctx:u}};for(let o=0;o<l.length;o+=1)s=fe(s,l[o]);return e=new Ge({props:s}),{c(){g(e.$$.fragment)},l(o){_(e.$$.fragment,o)},m(o,m){b(e,o,m),i=!0},p(o,[m]){const t=m&2?Ne(l,[m&2&&We(o[1]),m&0&&We(Oe)]):{};m&5&&(t.$$scope={dirty:m,ctx:o}),e.$set(t)},i(o){i||(k(e.$$.fragment,o),i=!0)},o(o){x(e.$$.fragment,o),i=!1},d(o){M(e,o)}}}const Oe={title:"Menu",desc:"Menu is used to display a list of links vertically or horizontally.",published:!0,layout:"components"};function ql(u,e,i){let l;return Je(u,Xe,s=>i(0,l=s)),u.$$set=s=>{i(1,e=fe(fe({},e),De(s)))},e=De(e),[l,e]}class Gl extends Fe{constructor(e){super(),Ke(this,e,ql,Ol,qe,{})}}export{Gl as component};
