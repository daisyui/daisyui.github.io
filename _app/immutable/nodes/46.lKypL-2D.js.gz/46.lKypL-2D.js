import{e as q,a as d,f as u,j as $,i as r,t as n,b as e,c as i}from"../chunks/disclose-version.ctAPnXXB.js";import{a as h}from"../chunks/actions.D_WyPHWg.js";import{l as X,s as G}from"../chunks/props.BH0qENYe.js";import{u as K,s as Q}from"../chunks/store.DhJ2LkXK.js";import{M as W}from"../chunks/mdsvex-components.CISdKOSk.js";import{C as Z,a as b,r as p,p as oo}from"../chunks/ClassTable.D_femxPu.js";import"../chunks/entry.DpYwZM8Q.js";import{B as lo}from"../chunks/BrowserSupport.D4hrfbMo.js";import{T as D}from"../chunks/Translate.BgWHrm2j.js";var to=n('<button class="btn">open modal</button> <dialog id="my_modal_1" class="modal"><div class="modal-box"><h3 class="font-bold text-lg">Hello!</h3> <p class="py-4">Press ESC key or click the button below to close</p> <div class="modal-action"><form method="dialog"><button class="btn">Close</button></form></div></div></dialog>',1),eo=n('<pre slot="html"> </pre>'),ao=n('<pre slot="jsx"> </pre>'),so=n('<button class="btn">open modal</button> <dialog id="my_modal_2" class="modal"><div class="modal-box"><h3 class="font-bold text-lg">Hello!</h3> <p class="py-4">Press ESC key or click outside to close</p></div> <form method="dialog" class="modal-backdrop"><button>close</button></form></dialog>',1),no=n('<pre slot="html"> </pre>'),mo=n('<pre slot="jsx"> </pre>'),io=n('<button class="btn">open modal</button> <dialog id="my_modal_3" class="modal"><div class="modal-box"><form method="dialog"><button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button></form> <h3 class="font-bold text-lg">Hello!</h3> <p class="py-4">Press ESC key or click on ✕ button to close</p></div></dialog>',1),co=n('<pre slot="html"> </pre>'),ro=n('<pre slot="jsx"> </pre>'),ho=n('<button class="btn">open modal</button> <dialog id="my_modal_4" class="modal"><div class="modal-box w-11/12 max-w-5xl"><h3 class="font-bold text-lg">Hello!</h3> <p class="py-4">Click the button below to close</p> <div class="modal-action"><form method="dialog"><button class="btn">Close</button></form></div></div></dialog>',1),po=n('<pre slot="html"> </pre>'),bo=n('<pre slot="jsx"> </pre>'),uo=n('<button class="btn">open modal</button> <dialog id="my_modal_5" class="modal modal-bottom sm:modal-middle"><div class="modal-box"><h3 class="font-bold text-lg">Hello!</h3> <p class="py-4">Press ESC key or click the button below to close</p> <div class="modal-action"><form method="dialog"><button class="btn">Close</button></form></div></div></dialog>',1),$o=n('<pre slot="html"> </pre>'),_o=n('<pre slot="jsx"> </pre>'),vo=n('<label for="my_modal_6" class="btn">open modal</label>'),go=n('<pre slot="html"> </pre>'),fo=n('<label for="my_modal_7" class="btn">open modal</label>'),yo=n('<pre slot="html"> </pre>'),xo=n('<a href="#my_modal_8" class="btn" rel="external">open modal</a>'),ko=n('<pre slot="html"> </pre>'),wo=n('<!> <!> <div class="alert text-sm"><div><span class="font-bold"><!></span> <ol><li>Using <code>&lt;dialog&gt;</code> element: It needs JS to open but it has better accessibility and we can close it using <span class="kbd kbd-xs">Esc</span> key</li> <li>Using a hidden <code>&lt;input type="checkbox"&gt;</code> and <code>&lt;label&gt;</code> to check/uncheck the checkbox and open/close the modal</li> <li>Using <code>&lt;a&gt;</code> anchor links: A link adds a parameter to the URL and you only see the modal when the URL has that parameter</li></ol></div></div> <div class="alert text-sm mt-4"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="stroke-current shrink-0 w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> <div><!></div></div> <h3 id="method-1-using-dialog-element-recommended"><a aria-hidden="true" tabindex="-1" href="#method-1-using-dialog-element-recommended"><span class="mr-1 opacity-20 hover:opacity-60 text-base font-bold inline-block align-middle relative -mt-1">#</span></a>Method 1: using dialog element <span class="badge badge-success">recommended</span></h3> <!> <!> <!> <!> <!> <h3 id="method-2-using-a-hidden-checkbox-legacy"><a aria-hidden="true" tabindex="-1" href="#method-2-using-a-hidden-checkbox-legacy"><span class="mr-1 opacity-20 hover:opacity-60 text-base font-bold inline-block align-middle relative -mt-1">#</span></a>Method 2: using a hidden checkbox <span class="badge badge-warning">legacy</span></h3> <!> <!> <h3 id="method-3-using-anchor-links-legacy"><a aria-hidden="true" tabindex="-1" href="#method-3-using-anchor-links-legacy"><span class="mr-1 opacity-20 hover:opacity-60 text-base font-bold inline-block align-middle relative -mt-1">#</span></a>Method 3: using anchor links <span class="badge badge-warning">legacy</span></h3> <!>',1);const Co={title:"Modal",desc:"Modal is used to show a dialog or a box when you click a button.",published:!0,layout:"components"};function Bo(H,j){const S=X(j,["children","$$slots","$$events"]),_={};K(_);const c=()=>Q(oo,"$prefix",_);var v=q(),V=u(v);W(V,G(()=>S,Co,{children:(B,Mo)=>{var g=wo(),f=u(g);lo(f,{data:{chrome:37,firefox:98,safari:15.4,iossafari:15.4}});var y=e(e(f,!0));Z(y,{data:[{type:"component",class:"modal",desc:"Container element"},{type:"component",class:"modal-box",desc:"The content of modal"},{type:"component",class:"modal-action",desc:"Container for modal action buttons"},{type:"component",class:"modal-backdrop",desc:"The backdrop that covers the back of modal so we can close the modal by clicking outside"},{type:"component",class:"modal-toggle",desc:"For hidden checkbox that controls modal"},{type:"modifier",class:"modal-open",desc:"Add/remove this class to open/close the modal using JS"},{type:"responsive",class:"modal-top",desc:"Moves the modal to top"},{type:"responsive",class:"modal-bottom",desc:"Moves the modal to bottom"},{type:"responsive",class:"modal-middle",desc:"Moves the modal to middle (default)"}]});var x=e(e(y,!0)),T=i(x),O=i(T),U=i(O);D(U,{text:"There are 3 ways to use a modal:"});var k=e(e(x,!0)),Y=i(k),A=e(e(Y,!0)),L=i(A);D(L,{text:"Make sure you're using unique IDs for each modal"});var z=e(e(k,!0)),w=e(e(z,!0));b(w,{title:"Dialog modal",desc:"opens on click using ID.showModal() method. can be closed using ID.close() method",children:(l,m)=>{var o=to(),t=u(o);$("click",t,my_modal_1.showModal(),!1),d(l,o)},$$slots:{html:(l,m)=>{var o=eo(),t=i(o);t.nodeValue=r(`<!-- Open the modal using ID.showModal() method -->
<button class="$$btn" onclick="my_modal_1.showModal()">open modal</button>
<dialog id="my_modal_1" class="$$modal">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Hello!</h3>
    <p class="py-4">Press ESC key or click the button below to close</p>
    <div class="$$modal-action">
      <form method="dialog">
        <!-- if there is a button in form, it will close the modal -->
        <button class="$$btn">Close</button>
      </form>
    </div>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)},jsx:(l,m)=>{var o=ao(),t=i(o);t.nodeValue=r(`{/* Open the modal using document.getElementById('ID').showModal() method */}
<button className="$$btn" onClick={()=>document.getElementById('my_modal_1').showModal()}>open modal</button>
<dialog id="my_modal_1" className="$$modal">
  <div className="$$modal-box">
    <h3 className="font-bold text-lg">Hello!</h3>
    <p className="py-4">Press ESC key or click the button below to close</p>
    <div className="$$modal-action">
      <form method="dialog">
        {/* if there is a button in form, it will close the modal */}
        <button className="$$btn">Close</button>
      </form>
    </div>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}});var C=e(e(w,!0));b(C,{title:"Dialog modal, closes when clicked outside",desc:"there is a second form with 'modal-backdrop' class and it covers the screen so we can close the modal when clicked outside",children:(l,m)=>{var o=so(),t=u(o);$("click",t,my_modal_2.showModal(),!1),d(l,o)},$$slots:{html:(l,m)=>{var o=no(),t=i(o);t.nodeValue=r(`<!-- Open the modal using ID.showModal() method -->
<button class="$$btn" onclick="my_modal_2.showModal()">open modal</button>
<dialog id="my_modal_2" class="$$modal">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Hello!</h3>
    <p class="py-4">Press ESC key or click outside to close</p>
  </div>
  <form method="dialog" class="$$modal-backdrop">
    <button>close</button>
  </form>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)},jsx:(l,m)=>{var o=mo(),t=i(o);t.nodeValue=r(`{/* Open the modal using document.getElementById('ID').showModal() method */}
<button className="$$btn" onClick={()=>document.getElementById('my_modal_2').showModal()}>open modal</button>
<dialog id="my_modal_2" className="$$modal">
  <div className="$$modal-box">
    <h3 className="font-bold text-lg">Hello!</h3>
    <p className="py-4">Press ESC key or click outside to close</p>
  </div>
  <form method="dialog" className="$$modal-backdrop">
    <button>close</button>
  </form>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}});var M=e(e(C,!0));b(M,{title:"Dialog modal with a close button at corner",children:(l,m)=>{var o=io(),t=u(o);$("click",t,my_modal_3.showModal(),!1),d(l,o)},$$slots:{html:(l,m)=>{var o=co(),t=i(o);t.nodeValue=r(`<!-- You can open the modal using ID.showModal() method -->
<button class="$$btn" onclick="my_modal_3.showModal()">open modal</button>
<dialog id="my_modal_3" class="$$modal">
  <div class="$$modal-box">
    <form method="dialog">
      <button class="$$btn $$btn-sm $$btn-circle $$btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <h3 class="font-bold text-lg">Hello!</h3>
    <p class="py-4">Press ESC key or click on ✕ button to close</p>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)},jsx:(l,m)=>{var o=ro(),t=i(o);t.nodeValue=r(`{/* You can open the modal using document.getElementById('ID').showModal() method */}
<button className="$$btn" onClick={()=>document.getElementById('my_modal_3').showModal()}>open modal</button>
<dialog id="my_modal_3" className="$$modal">
  <div className="$$modal-box">
    <form method="dialog">
      {/* if there is a button in form, it will close the modal */}
      <button className="$$btn $$btn-sm $$btn-circle $$btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <h3 className="font-bold text-lg">Hello!</h3>
    <p className="py-4">Press ESC key or click on ✕ button to close</p>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}});var P=e(e(M,!0));b(P,{title:"Dialog modal with custom width",desc:"You can use any w-* and max-w-* utility class to customize the width",children:(l,m)=>{var o=ho(),t=u(o);$("click",t,my_modal_4.showModal(),!1),d(l,o)},$$slots:{html:(l,m)=>{var o=po(),t=i(o);t.nodeValue=r(`<!-- You can open the modal using ID.showModal() method -->
<button class="$$btn" onclick="my_modal_4.showModal()">open modal</button>
<dialog id="my_modal_4" class="$$modal">
  <div class="$$modal-box w-11/12 max-w-5xl">
    <h3 class="font-bold text-lg">Hello!</h3>
    <p class="py-4">Click the button below to close</p>
    <div class="$$modal-action">
      <form method="dialog">
        <!-- if there is a button, it will close the modal -->
        <button class="$$btn">Close</button>
      </form>
    </div>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)},jsx:(l,m)=>{var o=bo(),t=i(o);t.nodeValue=r(`{/* You can open the modal using document.getElementById('ID').showModal() method */}
<button className="$$btn" onClick={()=>document.getElementById('my_modal_4').showModal()}>open modal</button>
<dialog id="my_modal_4" className="$$modal">
  <div className="$$modal-box w-11/12 max-w-5xl">
    <h3 className="font-bold text-lg">Hello!</h3>
    <p className="py-4">Click the button below to close</p>
    <div className="$$modal-action">
      <form method="dialog">
        {/* if there is a button, it will close the modal */}
        <button className="$$btn">Close</button>
      </form>
    </div>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}});var N=e(e(P,!0));b(N,{title:"Responsive",desc:"Modal goes bottom on mobile screen and goes middle on desktop",children:(l,m)=>{var o=uo(),t=u(o);$("click",t,my_modal_5.showModal(),!1),d(l,o)},$$slots:{html:(l,m)=>{var o=$o(),t=i(o);t.nodeValue=r(`<!-- Open the modal using ID.showModal() method -->
<button class="$$btn" onclick="my_modal_5.showModal()">open modal</button>
<dialog id="my_modal_5" class="$$modal $$modal-bottom sm:$$modal-middle">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Hello!</h3>
    <p class="py-4">Press ESC key or click the button below to close</p>
    <div class="$$modal-action">
      <form method="dialog">
        <!-- if there is a button in form, it will close the modal -->
        <button class="$$btn">Close</button>
      </form>
    </div>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)},jsx:(l,m)=>{var o=_o(),t=i(o);t.nodeValue=r(`{/* Open the modal using document.getElementById('ID').showModal() method */}
<button className="$$btn" onClick={()=>document.getElementById('my_modal_5').showModal()}>open modal</button>
<dialog id="my_modal_5" className="$$modal modal-bottom sm:$$modal-middle">
  <div className="$$modal-box">
    <h3 className="font-bold text-lg">Hello!</h3>
    <p className="py-4">Press ESC key or click the button below to close</p>
    <div className="$$modal-action">
      <form method="dialog">
        {/* if there is a button in form, it will close the modal */}
        <button className="$$btn">Close</button>
      </form>
    </div>
  </div>
</dialog>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}});var R=e(e(N,!0)),E=e(e(R,!0));b(E,{title:"Modal using label + hidden checkbox",children:(l,m)=>{var o=vo();d(l,o)},$$slots:{html:(l,m)=>{var o=go(),t=i(o);t.nodeValue=r(`<!-- The button to open modal -->
<label for="my_modal_6" class="$$btn">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my_modal_6" class="$$modal-toggle" />
<div class="$$modal" role="dialog">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Hello!</h3>
    <p class="py-4">This modal works with a hidden checkbox!</p>
    <div class="$$modal-action">
      <label for="my_modal_6" class="$$btn">Close!</label>
    </div>
  </div>
</div>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}});var I=e(e(E,!0));b(I,{title:"Modal that closes when clicked outside",desc:"Modal works with a hidden checkbox and labels can toggle the checkbox so we can use another label tag with 'modal-backdrop' class that covers the screen so we can close the modal when clicked outside",children:(l,m)=>{var o=fo();d(l,o)},$$slots:{html:(l,m)=>{var o=yo(),t=i(o);t.nodeValue=r(`<!-- The button to open modal -->
<label for="my_modal_7" class="$$btn">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my_modal_7" class="$$modal-toggle" />
<div class="$$modal" role="dialog">
  <div class="$$modal-box">
    <h3 class="text-lg font-bold">Hello!</h3>
    <p class="py-4">This modal works with a hidden checkbox!</p>
  </div>
  <label class="$$modal-backdrop" for="my_modal_7">Close</label>
</div>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}});var F=e(e(I,!0)),J=e(e(F,!0));b(J,{title:"Modal using anchor link",desc:"Anchor links might not work well on some SPA frameworks so if there are problems, use the first example",children:(l,m)=>{var o=xo();d(l,o)},$$slots:{html:(l,m)=>{var o=ko(),t=i(o);t.nodeValue=r(`<!-- The button to open modal -->
<a href="#my_modal_8" class="$$btn">open modal</a>
<!-- Put this part before </body> tag -->
<div class="$$modal" role="dialog" id="my_modal_8">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Hello!</h3>
    <p class="py-4">This modal works with anchor links</p>
    <div class="$$modal-action">
     <a href="#" class="$$btn">Yay!</a>
    </div>
  </div>
</div>`),h(o,(a,s)=>p(a,s),()=>({to:c()})),d(l,o)}}}),d(B,g)}})),d(H,v)}export{Bo as component};
