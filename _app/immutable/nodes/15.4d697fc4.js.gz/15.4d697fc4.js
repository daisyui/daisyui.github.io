import{s as S,O as L,A as O,T as y,a as b,c as k,i as p,d as m,f as d,g as h,x as M,j as f,z as D,l as B,h as V,m as j,y as C,X as T,D as z}from"../chunks/scheduler.1c9dfc36.js";import{S as X,i as F,b as _,d as v,m as g,a as $,t as w,e as x}from"../chunks/index.e0dd2bc6.js";import{g as G,a as R}from"../chunks/spread.8a54911c.js";import{M as J,p as K,C as N,a as H,r as E}from"../chunks/ClassTable.920c0ef3.js";function Q(c){let e,r='<ul><li><span class="hover:underline cursor-pointer inline-flex gap-2 items-center">Home</span></li> <li><span class="hover:underline cursor-pointer inline-flex gap-2 items-center">Documents</span></li> <li>Add Document</li></ul>';return{c(){e=d("div"),e.innerHTML=r,this.h()},l(t){e=h(t,"DIV",{class:!0,"data-svelte-h":!0}),M(e)!=="svelte-19d4qk"&&(e.innerHTML=r),this.h()},h(){f(e,"class","text-sm breadcrumbs")},m(t,a){p(t,e,a)},p:D,d(t){t&&m(e)}}}function U(c){let e,r=`<div class="text-sm $$breadcrumbs">
  <ul>
    <li><a>Home</a></li> 
    <li><a>Documents</a></li> 
    <li>Add Document</li>
  </ul>
</div>`,t,a,s,i;return{c(){e=d("pre"),t=B(r),this.h()},l(l){e=h(l,"PRE",{slot:!0});var o=V(e);t=j(o,r),o.forEach(m),this.h()},h(){f(e,"slot","html")},m(l,o){p(l,e,o),C(e,t),s||(i=T(a=E.call(null,e,{to:c[0]})),s=!0)},p(l,o){a&&z(a.update)&&o&1&&a.update.call(null,{to:l[0]})},d(l){l&&m(e),s=!1,i()}}}function W(c){let e,r=`<ul><li><span class="hover:underline cursor-pointer inline-flex gap-2 items-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Home</span></li> <li><span class="hover:underline cursor-pointer inline-flex gap-2 items-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Documents</span></li> <li><span class="inline-flex gap-2 items-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
        Add Document</span></li></ul>`;return{c(){e=d("div"),e.innerHTML=r,this.h()},l(t){e=h(t,"DIV",{class:!0,"data-svelte-h":!0}),M(e)!=="svelte-1vbre94"&&(e.innerHTML=r),this.h()},h(){f(e,"class","text-sm breadcrumbs")},m(t,a){p(t,e,a)},p:D,d(t){t&&m(e)}}}function Y(c){let e,r=`<div class="text-sm $$breadcrumbs">
  <ul>
    <li>
      <a>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Home
      </a>
    </li> 
    <li>
      <a>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Documents
      </a>
    </li> 
    <li>
      <span class="inline-flex gap-2 items-center">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
        Add Document
      </span>
    </li>
  </ul>
</div>`,t,a,s,i;return{c(){e=d("pre"),t=B(r),this.h()},l(l){e=h(l,"PRE",{slot:!0});var o=V(e);t=j(o,r),o.forEach(m),this.h()},h(){f(e,"slot","html")},m(l,o){p(l,e,o),C(e,t),s||(i=T(a=E.call(null,e,{to:c[0]})),s=!0)},p(l,o){a&&z(a.update)&&o&1&&a.update.call(null,{to:l[0]})},d(l){l&&m(e),s=!1,i()}}}function Z(c){let e,r="<ul><li>Long text 1</li> <li>Long text 2</li> <li>Long text 3</li> <li>Long text 4</li> <li>Long text 5</li></ul>";return{c(){e=d("div"),e.innerHTML=r,this.h()},l(t){e=h(t,"DIV",{class:!0,"data-svelte-h":!0}),M(e)!=="svelte-10d6jh1"&&(e.innerHTML=r),this.h()},h(){f(e,"class","max-w-xs text-sm breadcrumbs")},m(t,a){p(t,e,a)},p:D,d(t){t&&m(e)}}}function ee(c){let e,r=`<div class="max-w-xs text-sm $$breadcrumbs">
  <ul>
    <li>Long text 1</li>
    <li>Long text 2</li>
    <li>Long text 3</li>
    <li>Long text 4</li>
    <li>Long text 5</li>
  </ul>
</div>`,t,a,s,i;return{c(){e=d("pre"),t=B(r),this.h()},l(l){e=h(l,"PRE",{slot:!0});var o=V(e);t=j(o,r),o.forEach(m),this.h()},h(){f(e,"slot","html")},m(l,o){p(l,e,o),C(e,t),s||(i=T(a=E.call(null,e,{to:c[0]})),s=!0)},p(l,o){a&&z(a.update)&&o&1&&a.update.call(null,{to:l[0]})},d(l){l&&m(e),s=!1,i()}}}function te(c){let e,r,t,a,s,i,l,o;return e=new N({props:{data:[{type:"component",class:"breadcrumbs",desc:"Container element"}]}}),t=new H({props:{title:"Breadcrumbs",$$slots:{html:[U],default:[Q]},$$scope:{ctx:c}}}),s=new H({props:{title:"Breadcrumbs with icons",$$slots:{html:[Y],default:[W]},$$scope:{ctx:c}}}),l=new H({props:{title:"Breadcrumbs with max-width",desc:"If you set max-width or the list gets larger than the container it will scroll",$$slots:{html:[ee],default:[Z]},$$scope:{ctx:c}}}),{c(){_(e.$$.fragment),r=b(),_(t.$$.fragment),a=b(),_(s.$$.fragment),i=b(),_(l.$$.fragment)},l(n){v(e.$$.fragment,n),r=k(n),v(t.$$.fragment,n),a=k(n),v(s.$$.fragment,n),i=k(n),v(l.$$.fragment,n)},m(n,u){g(e,n,u),p(n,r,u),g(t,n,u),p(n,a,u),g(s,n,u),p(n,i,u),g(l,n,u),o=!0},p(n,u){const A={};u&5&&(A.$$scope={dirty:u,ctx:n}),t.$set(A);const I={};u&5&&(I.$$scope={dirty:u,ctx:n}),s.$set(I);const P={};u&5&&(P.$$scope={dirty:u,ctx:n}),l.$set(P)},i(n){o||($(e.$$.fragment,n),$(t.$$.fragment,n),$(s.$$.fragment,n),$(l.$$.fragment,n),o=!0)},o(n){w(e.$$.fragment,n),w(t.$$.fragment,n),w(s.$$.fragment,n),w(l.$$.fragment,n),o=!1},d(n){n&&(m(r),m(a),m(i)),x(e,n),x(t,n),x(s,n),x(l,n)}}}function se(c){let e,r;const t=[c[1],q];let a={$$slots:{default:[te]},$$scope:{ctx:c}};for(let s=0;s<t.length;s+=1)a=L(a,t[s]);return e=new J({props:a}),{c(){_(e.$$.fragment)},l(s){v(e.$$.fragment,s)},m(s,i){g(e,s,i),r=!0},p(s,[i]){const l=i&2?G(t,[i&2&&R(s[1]),i&0&&R(q)]):{};i&5&&(l.$$scope={dirty:i,ctx:s}),e.$set(l)},i(s){r||($(e.$$.fragment,s),r=!0)},o(s){w(e.$$.fragment,s),r=!1},d(s){x(e,s)}}}const q={title:"Breadcrumbs",desc:"Breadcrumbs helps users to navigate through the website.",published:!0,layout:"components"};function le(c,e,r){let t;return O(c,K,a=>r(0,t=a)),c.$$set=a=>{r(1,e=L(L({},e),y(a)))},e=y(e),[t,e]}class ie extends X{constructor(e){super(),F(this,e,le,se,S,{})}}export{ie as component};
